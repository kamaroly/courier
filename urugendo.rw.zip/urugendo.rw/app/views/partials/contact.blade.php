@extends('layouts.default')
@section('title')
Urugendo - Twandikire
@stop
@section('content')
<section id="about" class="about section">
        <div class="container">
            <h4 class="title text-center">Twishimiye kubakira</h4>
            <p class="intro text-center">Twizeyeko serivise tubaha ibagirira akamaro. Niba mufite icyifuzo cyangwa ikibazo, cyangwa se ikindi kintu icyo aricyo cyose mushaka kutugezaho mwatubona kuri aderesi zikurikira.</p>

            <p class="intro text-center">
            	Mutwandikire kuri
            	<i class="fa fa-envelope"></i> <span>urugendo.rw@gmail.com</span>
            </p>
            <p class="intro text-center">
            	Muduhamagare kuri
            	<i class="fa fa-phone"></i> <span> 0722000480 </span>
            </p>
             Murakoze - ikipe ya urugendo.rw .
        </div>
</section>
<br>
<br>
@stop